// test-sentry.js
// Quick test to verify Sentry integration is working

require('./instrument.js');
const { captureException, captureMessage } = require('./src/config/sentry');

console.log('Probando integración con Sentry...\n');

// Test 1: Capturar mensaje informativo
captureMessage('🧪 Mensaje de prueba desde PNPtv Bot', 'info', {
  test: true,
  timestamp: new Date().toISOString(),
  environment: process.env.NODE_ENV || 'production'
});
console.log('✓ Mensaje de prueba enviado a Sentry');

// Test 2: Capturar excepción
try {
  throw new Error('🧪 Error de prueba desde PNPtv Bot');
} catch (error) {
  captureException(error, {
    test: true,
    feature: 'sentry-setup',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'production'
  });
  console.log('✓ Error de prueba enviado a Sentry');
}

// Esperar a que Sentry envíe los eventos
console.log('\n⏳ Enviando eventos a Sentry...');
setTimeout(() => {
  console.log('\n✅ Prueba completada!');
  console.log('📊 Ve a https://sentry.io/ para ver los eventos.');
  console.log('   → Busca en Issues: "🧪 Error de prueba desde PNPtv Bot"\n');
  process.exit(0);
}, 2000);
