/**
 * Daimo Pay Integration Test Script
 * Tests configuration, payment link generation, and webhook readiness
 */

require('./src/config/env');
const daimo = require('./src/config/daimo');
const logger = require('./src/utils/logger');

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

function printHeader(text) {
  console.log(`\n${colors.bright}${colors.cyan}${'='.repeat(80)}`);
  console.log(`${text}`);
  console.log(`${'='.repeat(80)}${colors.reset}\n`);
}

function printSection(text) {
  console.log(`\n${colors.bright}${colors.blue}${text}${colors.reset}`);
  console.log(`${'-'.repeat(80)}`);
}

function printSuccess(text) {
  console.log(`${colors.green}✓${colors.reset} ${text}`);
}

function printError(text) {
  console.log(`${colors.red}✗${colors.reset} ${text}`);
}

function printWarning(text) {
  console.log(`${colors.yellow}⚠${colors.reset} ${text}`);
}

function printInfo(text) {
  console.log(`${colors.cyan}ℹ${colors.reset} ${text}`);
}

async function testDaimoIntegration() {
  printHeader('DAIMO PAY INTEGRATION TEST');

  let allTestsPassed = true;

  // =========================================================================
  // 1. ENVIRONMENT VARIABLES CHECK
  // =========================================================================
  printSection('1. ENVIRONMENT VARIABLES CHECK');

  const requiredVars = {
    'DAIMO_API_KEY': process.env.DAIMO_API_KEY,
    'DAIMO_APP_ID': process.env.DAIMO_APP_ID,
    'DAIMO_WEBHOOK_TOKEN': process.env.DAIMO_WEBHOOK_TOKEN,
    'BOT_URL': process.env.BOT_URL,
  };

  const optionalVars = {
    'NEXT_PUBLIC_DAIMO_APP_ID': process.env.NEXT_PUBLIC_DAIMO_APP_ID,
    'NEXT_PUBLIC_TREASURY_ADDRESS': process.env.NEXT_PUBLIC_TREASURY_ADDRESS,
    'NEXT_PUBLIC_REFUND_ADDRESS': process.env.NEXT_PUBLIC_REFUND_ADDRESS,
    'NEXT_PUBLIC_BOT_URL': process.env.NEXT_PUBLIC_BOT_URL,
    'PAYMENT_PAGE_URL': process.env.PAYMENT_PAGE_URL,
  };

  let envVarsOk = true;

  console.log('\nRequired Variables:');
  for (const [key, value] of Object.entries(requiredVars)) {
    if (value && value.trim() !== '') {
      printSuccess(`${key}: ${value.substring(0, 20)}...`);
    } else {
      printError(`${key}: NOT SET`);
      envVarsOk = false;
      allTestsPassed = false;
    }
  }

  console.log('\nOptional Variables (for payment page):');
  for (const [key, value] of Object.entries(optionalVars)) {
    if (value && value.trim() !== '') {
      printSuccess(`${key}: ${value.substring(0, 30)}...`);
    } else {
      printWarning(`${key}: NOT SET (may cause issues with payment page)`);
    }
  }

  if (envVarsOk) {
    printSuccess('\n✓ All required environment variables are configured');
  } else {
    printError('\n✗ Some required environment variables are missing');
    printInfo('\nTo fix: Add missing variables to your .env file');
    printInfo('See .env.example for reference');
  }

  // =========================================================================
  // 2. CREDENTIALS VALIDATION
  // =========================================================================
  printSection('2. CREDENTIALS VALIDATION');

  try {
    daimo.validateCredentials();
    printSuccess('Credentials validation passed');
  } catch (error) {
    printError(`Credentials validation failed: ${error.message}`);
    allTestsPassed = false;
  }

  // =========================================================================
  // 3. DAIMO CONFIG CHECK
  // =========================================================================
  printSection('3. DAIMO CONFIGURATION');

  const config = daimo.getConfig();
  console.log('\nConfiguration:');
  printInfo(`App ID: ${config.appId}`);
  printInfo(`API URL: ${config.apiUrl}`);
  printInfo(`Webhook URL: ${config.webhookUrl}`);
  printInfo(`Return URL: ${config.returnUrl}`);
  printInfo(`Enabled: ${config.enabled ? 'Yes' : 'No'}`);

  if (!config.enabled) {
    printWarning('\nDaimo Pay is NOT enabled - missing credentials');
    allTestsPassed = false;
  } else {
    printSuccess('\nDaimo Pay is properly configured');
  }

  // =========================================================================
  // 4. PAYMENT LINK GENERATION TEST
  // =========================================================================
  printSection('4. PAYMENT LINK GENERATION TEST');

  const testParams = {
    amount: 10.00,
    userId: 'test_user_' + Date.now(),
    userEmail: 'test@example.com',
    userName: 'Test User',
    plan: 'test_plan',
    description: 'Test subscription payment',
  };

  console.log('\nTest Parameters:');
  printInfo(`Amount: $${testParams.amount} USDC`);
  printInfo(`User ID: ${testParams.userId}`);
  printInfo(`Plan: ${testParams.plan}`);

  try {
    const paymentData = await daimo.createPaymentRequest(testParams);

    if (paymentData.success) {
      printSuccess('\n✓ Payment link created successfully');
      console.log('\nPayment Details:');
      printInfo(`Payment URL: ${paymentData.paymentUrl}`);
      printInfo(`Reference: ${paymentData.reference}`);
      printInfo(`Amount: ${paymentData.data.amount} ${paymentData.data.currency}`);
      printInfo(`Status: ${paymentData.data.status}`);
    } else {
      printError('Payment link creation failed');
      allTestsPassed = false;
    }
  } catch (error) {
    printError(`Payment link generation error: ${error.message}`);
    allTestsPassed = false;
  }

  // =========================================================================
  // 5. WEBHOOK ENDPOINTS CHECK
  // =========================================================================
  printSection('5. WEBHOOK ENDPOINTS');

  const botUrl = process.env.BOT_URL;
  if (botUrl) {
    console.log('\nWebhook Endpoints (configure these in Daimo dashboard):');
    printInfo(`Webhook URL: ${botUrl}/daimo/webhook`);
    printInfo(`Success URL: ${botUrl}/payment/success`);
    printInfo(`API Plan Endpoint: ${botUrl}/api/plans/{planId}`);
    printInfo(`Payment Started: ${botUrl}/api/payments/started`);
    printInfo(`Payment Completed: ${botUrl}/api/payments/completed`);

    printSuccess('\n✓ Webhook URLs are properly configured');
  } else {
    printError('BOT_URL not set - webhooks will not work');
    allTestsPassed = false;
  }

  // =========================================================================
  // 6. PAYMENT PAGE CHECK
  // =========================================================================
  printSection('6. PAYMENT PAGE (React + Next.js)');

  const paymentPageUrl = process.env.PAYMENT_PAGE_URL || (botUrl ? `${botUrl}/pay` : null);

  if (paymentPageUrl) {
    printInfo(`Payment Page URL: ${paymentPageUrl}`);
    printSuccess('Payment page URL configured');

    if (process.env.NEXT_PUBLIC_TREASURY_ADDRESS) {
      printSuccess(`Treasury Address: ${process.env.NEXT_PUBLIC_TREASURY_ADDRESS}`);
    } else {
      printError('NEXT_PUBLIC_TREASURY_ADDRESS not set - payments will fail');
      printInfo('This is the wallet address where you will receive USDC payments');
      allTestsPassed = false;
    }
  } else {
    printError('Payment page URL not configured');
    allTestsPassed = false;
  }

  // =========================================================================
  // 7. INTEGRATION CHECKLIST
  // =========================================================================
  printSection('7. INTEGRATION CHECKLIST');

  console.log('\nDeployment Checklist:');
  console.log('[ ] 1. Configure webhook URL in Daimo dashboard');
  console.log('[ ] 2. Set up treasury wallet address for receiving USDC');
  console.log('[ ] 3. Deploy payment page (Next.js app in src/payment-page)');
  console.log('[ ] 4. Test payment flow end-to-end');
  console.log('[ ] 5. Verify webhook authentication with DAIMO_WEBHOOK_TOKEN');
  console.log('[ ] 6. Test subscription activation after payment');

  console.log('\nPayment Page Commands:');
  printInfo('Development: npm run dev:payment');
  printInfo('Build: npm run build:payment');
  printInfo('Start: npm run start:payment');

  // =========================================================================
  // 8. KNOWN ISSUES
  // =========================================================================
  printSection('8. KNOWN ISSUES & WARNINGS');

  printWarning('ISSUE #1: Duplicate webhook processing in webhook.js');
  printInfo('  - Lines 503-583: First payment_completed handler');
  printInfo('  - Lines 606-676: Second payment_completed handler (redundant)');
  printInfo('  - This may cause double processing or conflicts');
  printInfo('  - RECOMMENDATION: Remove duplicate code');

  printWarning('\nISSUE #2: Heroku app is currently down');
  printInfo('  - Health check returned application error');
  printInfo('  - Webhooks will not be received until app is redeployed');
  printInfo('  - Check Heroku logs: heroku logs --tail');

  // =========================================================================
  // FINAL SUMMARY
  // =========================================================================
  printHeader('TEST SUMMARY');

  if (allTestsPassed) {
    console.log(`${colors.bright}${colors.green}`);
    console.log('✅ ALL TESTS PASSED');
    console.log('\nDaimo Pay integration is properly configured!');
    console.log('Next steps:');
    console.log('1. Deploy payment page');
    console.log('2. Configure webhook in Daimo dashboard');
    console.log('3. Create a test plan with paymentMethod: "daimo"');
    console.log('4. Test complete payment flow');
    console.log(colors.reset);
  } else {
    console.log(`${colors.bright}${colors.red}`);
    console.log('❌ SOME TESTS FAILED');
    console.log('\nPlease fix the issues above before deploying.');
    console.log('Check the error messages and warnings for details.');
    console.log(colors.reset);
  }

  console.log('\n' + '='.repeat(80) + '\n');
}

// Run the test
testDaimoIntegration()
  .then(() => {
    process.exit(0);
  })
  .catch((error) => {
    console.error(`\n${colors.red}Fatal error:${colors.reset}`, error);
    process.exit(1);
  });