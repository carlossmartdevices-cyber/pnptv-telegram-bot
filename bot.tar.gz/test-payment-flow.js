/**
 * Payment Flow Test Script
 * Tests the complete payment flow including payment link creation and webhook processing
 */

require("./src/config/env");
const { db } = require("./src/config/firebase");
const planService = require("./src/services/planService");
const epayco = require("./src/config/epayco");
const daimo = require("./src/config/daimo");
const logger = require("./src/utils/logger");

// Test colors
const colors = {
  green: "\x1b[32m",
  red: "\x1b[31m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  cyan: "\x1b[36m",
  reset: "\x1b[0m",
};

function logSuccess(message) {
  console.log(`${colors.green}✓ ${message}${colors.reset}`);
}

function logError(message) {
  console.log(`${colors.red}✗ ${message}${colors.reset}`);
}

function logInfo(message) {
  console.log(`${colors.blue}ℹ ${message}${colors.reset}`);
}

function logWarning(message) {
  console.log(`${colors.yellow}⚠ ${message}${colors.reset}`);
}

function logStep(message) {
  console.log(`${colors.cyan}▶ ${message}${colors.reset}`);
}

async function testPaymentFlow() {
  console.log("\n" + "=".repeat(70));
  console.log("Payment Flow Integration Test");
  console.log("=".repeat(70) + "\n");

  try {
    // Step 1: Check available plans
    logStep("Step 1: Checking available subscription plans...");
    const plans = await planService.getActivePlans();

    if (plans.length === 0) {
      logError("No active plans found in database");
      logInfo("Please create plans first using the bot or admin panel");
      process.exit(1);
    }

    logSuccess(`Found ${plans.length} active plan(s)`);

    // Display plans
    console.log("\nAvailable Plans:");
    plans.forEach((plan, index) => {
      console.log(`\n  ${index + 1}. ${plan.displayName || plan.name}`);
      console.log(`     - ID: ${plan.id}`);
      console.log(`     - Tier: ${plan.tier}`);
      console.log(`     - Price: $${plan.price || plan.priceInCOP} ${plan.currency || "COP"}`);
      console.log(`     - Duration: ${plan.duration || plan.durationDays} days`);
      console.log(`     - Payment Method: ${plan.paymentMethod || "epayco"}`);

      if (plan.features && plan.features.length > 0) {
        console.log(`     - Features: ${plan.features.slice(0, 2).join(", ")}...`);
      }
    });

    console.log("");

    // Step 2: Select a test plan (first ePayco plan)
    logStep("Step 2: Selecting test plan for payment link generation...");

    const epaycoPlans = plans.filter(p => !p.paymentMethod || p.paymentMethod === "epayco");
    const daimoPlans = plans.filter(p => p.paymentMethod === "daimo");

    if (epaycoPlans.length === 0) {
      logWarning("No ePayco plans found - will test with first available plan");
    }

    const testPlan = epaycoPlans[0] || plans[0];
    logSuccess(`Selected plan: ${testPlan.displayName || testPlan.name} (${testPlan.id})`);

    // Step 3: Create test user data
    logStep("Step 3: Creating test user data...");
    const testUserId = "test_user_" + Date.now();
    const testUserData = {
      userId: testUserId,
      userEmail: `${testUserId}@telegram.user`,
      userName: "Test User",
      firstName: "Test",
      username: "testuser",
    };
    logSuccess("Test user data created");
    logInfo(`User ID: ${testUserId}`);

    // Step 4: Test ePayco payment link creation
    if (!testPlan.paymentMethod || testPlan.paymentMethod === "epayco") {
      console.log("");
      logStep("Step 4: Testing ePayco payment link creation...");

      try {
        const paymentData = await epayco.createPaymentLink({
          name: testPlan.name,
          description: testPlan.description || `${testPlan.name} subscription`,
          amount: testPlan.price || testPlan.priceInCOP,
          currency: testPlan.currency || "COP",
          userId: testUserId,
          userEmail: testUserData.userEmail,
          userName: testUserData.userName,
          plan: testPlan.id,
        });

        if (paymentData.success && paymentData.paymentUrl) {
          logSuccess("ePayco payment link created successfully!");
          console.log(`\n  Payment URL:`);
          console.log(`  ${colors.cyan}${paymentData.paymentUrl}${colors.reset}\n`);
          console.log(`  Reference: ${paymentData.reference}`);
          console.log(`  Invoice ID: ${paymentData.invoiceId}`);

          logInfo("\nTo test the payment:");
          console.log(`  1. Open the payment URL in your browser`);
          console.log(`  2. Use test card: 4575623182290326`);
          console.log(`  3. CVV: 123, Exp: 12/25`);
          console.log(`  4. Complete the payment`);
          console.log(`  5. You'll be redirected to success page`);
          console.log(`  6. Webhook will be sent to: ${process.env.BOT_URL}/epayco/confirmation\n`);
        } else {
          logError("Failed to create payment link");
        }
      } catch (error) {
        logError(`ePayco payment link creation failed: ${error.message}`);
      }
    }

    // Step 5: Test Daimo payment link creation
    if (daimoPlans.length > 0) {
      console.log("");
      logStep("Step 5: Testing Daimo Pay payment link creation...");

      const daimoPlan = daimoPlans[0];
      try {
        const amountUSD = daimoPlan.currency === "USD"
          ? daimoPlan.price
          : (daimoPlan.price || daimoPlan.priceInCOP) / 4000; // Rough COP to USD conversion

        const paymentData = await daimo.createPaymentRequest({
          amount: amountUSD,
          userId: testUserId,
          userEmail: testUserData.userEmail,
          userName: testUserData.userName,
          plan: daimoPlan.id,
          description: daimoPlan.description || `${daimoPlan.name} subscription`,
        });

        if (paymentData.success && paymentData.paymentUrl) {
          logSuccess("Daimo Pay payment link created successfully!");
          console.log(`\n  Payment URL:`);
          console.log(`  ${colors.cyan}${paymentData.paymentUrl}${colors.reset}\n`);
          console.log(`  Reference: ${paymentData.reference}`);
          console.log(`  Amount: $${amountUSD.toFixed(2)} USD (USDC)`);

          logInfo("\nTo test Daimo payment:");
          console.log(`  1. Open the payment URL in your browser`);
          console.log(`  2. Connect your crypto wallet`);
          console.log(`  3. Pay with USDC on supported chains (Base, Optimism, etc.)`);
          console.log(`  4. Webhook will be sent to: ${process.env.BOT_URL}/daimo/webhook\n`);
        } else {
          logError("Failed to create Daimo payment link");
        }
      } catch (error) {
        logError(`Daimo payment link creation failed: ${error.message}`);
      }
    }

    // Step 6: Summary and next steps
    console.log("\n" + "=".repeat(70));
    logSuccess("Payment Flow Test Completed!");
    console.log("=".repeat(70));

    console.log("\n📋 Test Summary:");
    console.log(`  ✓ Found ${plans.length} active plan(s)`);
    console.log(`  ✓ ePayco plans: ${epaycoPlans.length}`);
    console.log(`  ✓ Daimo plans: ${daimoPlans.length}`);
    console.log(`  ✓ Payment links generated successfully`);

    console.log("\n🔍 What was tested:");
    console.log(`  ✓ Database connection to Firestore`);
    console.log(`  ✓ Plan retrieval with Redis caching`);
    console.log(`  ✓ ePayco payment link generation`);
    console.log(`  ✓ Daimo payment link generation`);
    console.log(`  ✓ Signature generation for webhooks`);

    console.log("\n⚠️  What still needs testing:");
    console.log(`  ⧗ Actual payment completion (use test cards above)`);
    console.log(`  ⧗ Webhook delivery from payment providers`);
    console.log(`  ⧗ Subscription activation in database`);
    console.log(`  ⧗ Telegram notification to user`);

    console.log("\n📝 Next Steps:");
    console.log(`  1. Complete a test payment using the link above`);
    console.log(`  2. Check webhook logs to verify confirmation received`);
    console.log(`  3. Verify subscription activated in Firestore`);
    console.log(`  4. Check that user receives Telegram notification`);
    console.log(`  5. If bot is not running, deploy to Heroku/Railway first\n`);

    console.log("💡 Quick Commands:");
    console.log(`  - Start bot locally: npm start`);
    console.log(`  - Deploy to Railway: railway deploy`);
    console.log(`  - Check logs: railway logs (or heroku logs --tail)`);
    console.log(`  - View plans: Use bot command /admin → Plans\n`);

  } catch (error) {
    console.log("\n" + "=".repeat(70));
    logError("Test Failed!");
    console.log("=".repeat(70));
    console.error(`\nError: ${error.message}`);
    console.error(error.stack);
    process.exit(1);
  }
}

// Run the test
testPaymentFlow()
  .then(() => {
    console.log(`${colors.green}✨ Test completed successfully!${colors.reset}\n`);
    process.exit(0);
  })
  .catch((error) => {
    logError(`Test failed: ${error.message}`);
    console.error(error);
    process.exit(1);
  });
