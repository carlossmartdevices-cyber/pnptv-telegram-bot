with open('src/bot/index.js', 'rb') as f:
    data = f.read()
print(set(data))
