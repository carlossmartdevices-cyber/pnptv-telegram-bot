// Empty placeholder - all plans are now created dynamically by admins
// This file is kept for backward compatibility
const plans = {};

module.exports = plans;
